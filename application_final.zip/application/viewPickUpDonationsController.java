package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;

public class viewPickUpDonationsController implements Initializable {

	   @FXML
	    private Button backButton;
	   @FXML
	    private TableView<HelperClassTable2> donationTable;
	   @FXML
	    private TableColumn<HelperClassTable2, String> donorIDTableColumn;
		@FXML
		private TableColumn<HelperClassTable2, String> donorStatusTableColumn;
		@FXML
		private TableColumn<HelperClassTable2, String> donorNameTableColumn;
	   @FXML
	    private TableColumn<HelperClassTable2, String> donorAddressTableColumn;
	   @FXML
	    private TableColumn<HelperClassTable2, String> postalCodeTableColumn;
	   @FXML
	    private TableColumn<HelperClassTable2, String> phoneNumberTableColumn;
	   @FXML
	    private TableColumn<HelperClassTable2, String> pickUpDateTableColumn;
	   
	   public ObservableList<HelperClassTable2> list;
	   private ObservableList<String> comboList;
	   private int g_volID;

	   @Override
		public void initialize(URL arg0, ResourceBundle arg1) {
		   donorNameTableColumn.setCellValueFactory(new PropertyValueFactory<HelperClassTable2, String>("name"));
		   donorAddressTableColumn.setCellValueFactory(new PropertyValueFactory<HelperClassTable2, String>("address"));
		   postalCodeTableColumn.setCellValueFactory(new PropertyValueFactory<HelperClassTable2, String>("postalCode"));
		   phoneNumberTableColumn.setCellValueFactory(new PropertyValueFactory<HelperClassTable2, String>("phoneNumber"));
		   pickUpDateTableColumn.setCellValueFactory(new PropertyValueFactory<HelperClassTable2, String>("pickUpDate"));
		   donorIDTableColumn.setCellValueFactory(new PropertyValueFactory<HelperClassTable2, String>("donationID"));
		   donorStatusTableColumn.setCellValueFactory(new PropertyValueFactory<HelperClassTable2, String>("donationStatus"));
		   //call query to get list of donors.
			System.out.println("VolunteerID: " +CurrentUser.getCurrentUser());
			int id= CurrentUser.getCurrentUser();
		   list = FXCollections.observableArrayList();
		   comboList=FXCollections.observableArrayList();
		   //call query to get all volunteers
		   try {
			   Connection con = ConnectionProvider.getCon();
			   Statement stmt = con.createStatement();
			   String sql= "select donations.donationID as donationID ,donors.donorID as donorID, donors.firstName as name , donors.streetAddress as address ,donors.postalCode as postalCode , donors.phoneNumber as phoneNumber ,donations.timeRequested as pickUpDate ,volunteers.volunteerID as volunteerID , donations.donationStatus from donations inner join donors on donations.donorID =donors.donorID \n" +
					   		"inner join organizations on donations.organizationID = organizations.organizationID inner join volunteers on donations.volunteerID =volunteers.volunteerID where donations.donationStatus= 'forPickup'";
			   ResultSet rs = stmt.executeQuery(sql);


			   while(rs.next())
			   {
				   System.out.println("got donors..");
				   String s = String.format("%s",rs.getInt("donationID"));
				   HelperClassTable2 n = new HelperClassTable2(rs.getString("donationID"), rs.getString("name"), rs.getString("address"), rs.getString("postalCode"), rs.getString("phoneNumber"), rs.getString("pickUpDate"),rs.getString("donationStatus"));
				   list.add(n);
				   comboList.add(s);
			   }

			   con.close();


			   Connection con2=ConnectionProvider.getCon();
			   Statement stmt2 = con.createStatement();
			   String sql2 ="select volunteerID from volunteers where accountID='" +id+"'";
			   ResultSet rs2 = stmt2.executeQuery(sql2);

			   if(rs2.next())
			   {
				   g_volID=rs2.getInt("volunteerID");
			   }


		   }catch (Exception e) {System.out.print(e);}
		   donationTable.setItems(list);
		}

	 public void back(ActionEvent event) throws IOException{
	    	MainController m = new MainController();
			m.changeScene("HomePageVolunteer.fxml");
	    }
	   
	 public void logOutFromAccount(ActionEvent event) throws IOException{
	    	MainController m = new MainController();
			m.changeScene("loginUpdated.fxml");
	    }
	 public void pickUpAction(ActionEvent event) throws IOException{
		   String id = donationTable.getSelectionModel().getSelectedItem().getDonationID();
		   int volID= g_volID;
		 //send query change status to onRoute and volunteer ID to their id
		 try {
			 Connection con = ConnectionProvider.getCon();
			 Statement stmt = con.createStatement();
			 String sql= "update donations set donationStatus = 'onRoute' ,volunteerID ='"+volID+"' where donationID= '"+ id +"'";
			 int rs = stmt.executeUpdate(sql);
			 System.out.println("updated: "+ rs);


			 Alert alert = new Alert(Alert.AlertType.INFORMATION);
			 alert.setTitle("Donation: "+id +" On Route");
			 alert.setHeaderText(null);
			 alert.setContentText("Drive Safe!");

			 alert.showAndWait();

			 //done
			 con.close();

		 }catch (Exception e) {System.out.print(e);}
		 //show alert safe drive


		}
	
}