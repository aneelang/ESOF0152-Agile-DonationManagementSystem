package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ModifyAccountController {
	//Create connections to the FXML instances
	@FXML
	private Button submitButton;
	@FXML
	private Button backButton;
	@FXML
	private TextField firstNameTextField;
	@FXML
	private TextField lastNameTextField;
	@FXML
	private TextField emailTextField;
	@FXML
	private TextArea streetAddressTextArea;
	@FXML
	private TextField unitNumberTextField;
	@FXML
	private TextField cityTextField;
	@FXML
	private TextField provinceTextField;
	@FXML
	private TextField postalCodeTextField;
	@FXML
	private TextField birthDateTextField;
	@FXML
	private TextField phoneNumberTextField;
	
	public void back(ActionEvent event) throws IOException{		
		MainController m = new MainController();
		m.changeScene("HomePageVolunteer.fxml");
	}
	
	public void submit(ActionEvent event) throws IOException{
		int currentVolunteerID = -1;
		int currentUserID = CurrentUser.getCurrentUser();
		
		try {
			Connection con1 = ConnectionProvider.getCon();
	        Statement stmt1 = con1.createStatement();
	        String sql1 = "Select volunteerID from volunteers where accountID = " + currentUserID;
	        ResultSet rs1 = stmt1.executeQuery(sql1);
	        while (rs1.next()) {
	        	currentVolunteerID = rs1.getInt("volunteerID");
	        }
							
            Connection con2 = ConnectionProvider.getCon();
            String sql2 = "update volunteers" +  " set firstName = ?, lastName = ?, volunteerEmail = ?, streetAddress = ?, unitNumber = ?, city = ?, province = ?, postalCode = ?, birthDate = ?, volunteerPhoneNumber = ?" + " where volunteerID = ?";        
            PreparedStatement rs2 = con2.prepareStatement(sql2);
            
            rs2.setString(1, firstNameTextField.getText());
            rs2.setString(2, lastNameTextField.getText());
            rs2.setString(3, emailTextField.getText());
            rs2.setString(4, streetAddressTextArea.getText());
            rs2.setString(5, unitNumberTextField.getText());
            rs2.setString(6, cityTextField.getText());
            rs2.setString(7, provinceTextField.getText());
            rs2.setString(8, postalCodeTextField.getText());
            rs2.setString(9, birthDateTextField.getText());
            rs2.setString(10, phoneNumberTextField.getText());
            rs2.setInt(11, currentVolunteerID);     
            
            rs2.execute();
            con2.close();                          

        }catch (Exception e) {System.out.print(e);}
		
		System.out.println("Working");
		MainController m = new MainController();
		m.changeScene("HomePageVolunteer.fxml");
	}
}
