package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.sql.ResultSetMetaData;

public class SeeVolunteerOrgController  implements Initializable {
	 	
	@FXML
	    private Button logoutButton;
	   @FXML
	    private TableView<HelperClassVolunteerTable> volunteerTable;
	   @FXML
	    private TableColumn<HelperClassVolunteerTable, String> firstName;
	   @FXML
	    private TableColumn<HelperClassVolunteerTable, String> lastName;
	   @FXML
	    private TableColumn<HelperClassVolunteerTable, String> postalCode;
	   @FXML
	    private TableColumn<HelperClassVolunteerTable, String> phoneNumber;
	   @FXML
		public ComboBox<String> selectComboBox;
		@FXML
		private ListView lv_combo;
	   
	   
	   //Use helper class to add to table
	   //public ObservableList<HelperClassVolunteerTable> list = FXCollections.observableArrayList(
		//	   new HelperClassVolunteerTable("Angel","Mar","P7B5E1","807-312-1232"),
		//	   new HelperClassVolunteerTable("Shane","V","P7B5E1","807-312-1232")
		//	   );

		private ObservableList<HelperClassVolunteerTable> list;
		private ObservableList<String> comboList;
	   //Fill the table at start of program
		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			firstName.setCellValueFactory(new PropertyValueFactory<HelperClassVolunteerTable, String>("firstName"));
			lastName.setCellValueFactory(new PropertyValueFactory<HelperClassVolunteerTable, String>("lastName"));
			postalCode.setCellValueFactory(new PropertyValueFactory<HelperClassVolunteerTable, String>("postalCode"));
			phoneNumber.setCellValueFactory(new PropertyValueFactory<HelperClassVolunteerTable, String>("phoneNumber"));

			list =  FXCollections.observableArrayList();
			comboList=FXCollections.observableArrayList();
			//call query to get all volunteers
			try {
				Connection con = ConnectionProvider.getCon();
				Statement stmt = con.createStatement();
				String sql= "Select volunteerID,firstName, lastName, postalCode, volunteerPhoneNumber from volunteers";
				ResultSet rs = stmt.executeQuery(sql);


				while(rs.next())
				{
					System.out.println("got volunteers..");
					String s= String.format("%s: %s, %s",rs.getInt("volunteerID"),rs.getString("lastName"),rs.getString("firstName"));
					HelperClassVolunteerTable n= new HelperClassVolunteerTable(rs.getString("firstName"),rs.getString("lastName"),rs.getString("postalCode"),rs.getString("volunteerPhoneNumber"));
					list.add(n);
					comboList.add(s);
				}

				//done
				con.close();

			}catch (Exception e) {System.out.print(e);}

			volunteerTable.setItems(list);

			//fill combo box
			selectComboBox.setItems(comboList);



		}

		public void comboAction(ActionEvent event)
		{
			String[] parts= selectComboBox.getValue().toString().split(":");
			System.out.println(parts[0]);
			ObservableList<String> lv_strings= FXCollections.observableArrayList();

			lv_combo.getItems().clear();
			String s="";

			try {
				Connection con = ConnectionProvider.getCon();
				Statement stmt = con.createStatement();
				String sql= "Select * from volunteers where volunteerID='" + parts[0] +"'";
				ResultSet rs = stmt.executeQuery(sql);


				if(rs.next())
				{

					ResultSetMetaData rsmd = rs.getMetaData();
					int colcount= rsmd.getColumnCount();
					//System.out.println(colcount);
					for(int i=1; i<=colcount;i++)
					{
						s = s.concat(rsmd.getColumnName(i).toString()+ " : "+rs.getString(i).toString()+ "\n");
						String item= rsmd.getColumnName(i).toString()+ " : "+rs.getString(i).toString();
						lv_combo.getItems().add(item);

					}


				}
				//System.out.println(s);
				Alert alert = new Alert(Alert.AlertType.INFORMATION);
				alert.setTitle("Volunteer Information");
				alert.setHeaderText(null);
				alert.setContentText(s);

				alert.showAndWait();
				//done
				con.close();

			}catch (Exception e) {System.out.print(e);}

		}

	   public void back(ActionEvent event) throws IOException{
	    	MainController m = new MainController();
			m.changeScene("HomePageOrganization.fxml");
	    }

	 public void logOutFromAccount(ActionEvent event) throws IOException{
	    	MainController m = new MainController();
			m.changeScene("loginUpdated.fxml");
	    }


}
