package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

public class ModifyAvailabilityController {

	//Create connections to the FXML instances
		@FXML
		private Button makeChangesButton;
		@FXML
		private Button backButton;
		@FXML
		private TextArea availabilityTextArea;
		
		public void makeChanges(ActionEvent event) throws IOException{						
			
			int currentVolunteerID = -1;
			int currentUserID = CurrentUser.getCurrentUser();

			//added this for demo
			//split availability
			String[] parts=availabilityTextArea.getText().toString().split(",");
			try {
				System.out.println(currentUserID);
				Connection con1 = ConnectionProvider.getCon();
		        Statement stmt1 = con1.createStatement();
		        String sql1 = "Select volunteerID from volunteers where accountID = " + currentUserID;
		        ResultSet rs1 = stmt1.executeQuery(sql1);
		        while (rs1.next()) {
		        	currentVolunteerID = rs1.getInt("volunteerID");
		        }
				con1.close();


				Connection con2 = ConnectionProvider.getCon();
	            String sql2 = "update volunteers set availabilityDaysOfWeek = ? , availabilityHours= ? where volunteerID = ?";
	            PreparedStatement rs2 = con2.prepareStatement(sql2);
	            
	            rs2.setString(1, parts[0]);
				rs2.setString(2, parts[1]);
	            rs2.setInt(3, currentVolunteerID);
	            
	            rs2.execute();
	            con2.close();                          

	        }catch (Exception e) {System.out.print(e);}
			
			System.out.println("Working");
			
			MainController m = new MainController();
			m.changeScene("HomePageVolunteer.fxml");
		}
		
		public void back(ActionEvent event) throws IOException{
			MainController m = new MainController();
			m.changeScene("HomePageVolunteer.fxml");
		}
}
