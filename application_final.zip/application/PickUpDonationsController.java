package application;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class PickUpDonationsController implements Initializable {

    @Override
    public void initialize(URL arg0, ResourceBundle arg1){

    }
    public void back(ActionEvent event) throws IOException {
        MainController m = new MainController();
        m.changeScene("HomePageOrganization.fxml");
    }
}
