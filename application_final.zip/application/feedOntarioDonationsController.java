package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class feedOntarioDonationsController implements Initializable {

public feedOntarioDonationsController() {
		
	}

	
	//Create connections to the FXML instances
	@FXML
	private Button b_back;
	@FXML
	private TextArea l_needed;
	@FXML
	private Button submitButton;
	@FXML
	private Button contactUsButton;
	@FXML
	private TextArea donationTextArea;
	

	@Override
	public void initialize(URL arg0, ResourceBundle arg1){
		String orgID="1";
		l_needed.setText("");
		String s="";
		try {
			Connection con = ConnectionProvider.getCon();
			Statement stmt = con.createStatement();
			String sql= "select itemsRequestedFromDonors from organizations where organizationID='"+ orgID+"'";
			ResultSet rs = stmt.executeQuery(sql);

			if(rs.next())
			{
				System.out.println("got org info..");
				l_needed.setText(rs.getString("itemsRequestedFromDonors"));

			}

			//done
			con.close();

		}catch (Exception e) {System.out.print(e);}

	}
	public void submit(ActionEvent event) throws IOException{
		
		int forId = 0;
		int currentUserID = CurrentUser.getCurrentUser();
		int currentDonorID = -1;
		
		try {
			Connection con1 = ConnectionProvider.getCon();
	        Statement stmt1 = con1.createStatement();
	        String sql1 = "Select donationID from donations";
	        ResultSet rs1 = stmt1.executeQuery(sql1);
	        while (rs1.next()) {
	        	forId = rs1.getInt("donationID") + 1;
	        }
	        con1.close();
	        
	        Connection con2 = ConnectionProvider.getCon();
	        Statement stmt2 = con2.createStatement();
	        String sql2 = "Select donorID from donors where accountID = " + currentUserID;
	        ResultSet rs2 = stmt2.executeQuery(sql2);
	        while (rs2.next()) {
	        	currentDonorID = rs2.getInt("donorID");
	        }
	        con2.close();
	        	    
	    if (currentDonorID != -1)
	    {
	    	Connection con3 = ConnectionProvider.getCon();
            String sql3 = " insert into donations (donationID, itemsDonated, donorID, volunteerID, organizationID, timeRequested, donationStatus)" + " values (?, ?, ?, ?, ?, ?,?)";
            
            PreparedStatement rs3 = con3.prepareStatement(sql3);
            rs3.setInt (1, forId);
            rs3.setString (2, donationTextArea.getText());
            rs3.setInt (3, currentDonorID);
            rs3.setInt (4, 0);
            rs3.setInt (5, 1);
            rs3.setTimestamp (6, new Timestamp(System.currentTimeMillis()));
			rs3.setString(7,"forPickup");
            rs3.execute();
            con3.close();
	    }
            
	    else
	    {
	    	System.out.println("No valid donor ID...");
	    }
	    
        }catch (Exception e) {System.out.print(e);}
		
		MainController m = new MainController();
		m.changeScene("HomePageDonors.fxml");
	}
	
	public void contact(ActionEvent event) throws IOException{
		MainController m = new MainController();
		m.changeScene("feedOntarioContactPage.fxml");
	}

	public void back(ActionEvent event) throws IOException{
		MainController m = new MainController();
		m.changeScene("HomePageDonors.fxml");
	}
}
