package application;

import java.awt.desktop.SystemEventListener;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import org.w3c.dom.Text;

import javax.swing.*;

public class EditOrgController implements Initializable {

	//Create connections to the FXML instances
		@FXML
		private TextArea missionVisionTextArea;
		@FXML
		private TextField phoneNumberField;
		@FXML
		private TextField postalCodeField1;
		@FXML
		private TextField provinceChoiceBox;
		@FXML
		private TextField cityField;
		@FXML
		private TextField unitNumberField;
		@FXML
		private TextField streetAddressField;
		@FXML
		private TextField websiteURLField;
		@FXML
		private TextField organizationNameField;
		@FXML
		private Button submit;
		@FXML
		private Button uploadButton;
		@FXML
		private Button backButton;
		
		//Let user upload a picture
		public void uploadPicture(ActionEvent event) throws IOException{
			
		}

		@Override
		public void initialize(URL arg0, ResourceBundle arg1){
			//account id
			int id= CurrentUser.getCurrentUser();

			//Hardcoded org ID since 2 orgs have same orgID... might have to change this. but for demo should be okay?
			String orgID= "0";
			//first fill
			try {
				Connection con = ConnectionProvider.getCon();
				Statement stmt = con.createStatement();
				String sql= "select * from organizations where organizationID='"+ orgID+"'";
				ResultSet rs = stmt.executeQuery(sql);

				if(rs.next())
				{
					System.out.println("got org info..");
					organizationNameField.setText(rs.getString("organizationName"));
					websiteURLField.setText(rs.getString("organizationURL"));
					streetAddressField.setText(rs.getString("streetAddress"));
					unitNumberField.setText(rs.getString("unitNumber"));
					cityField.setText(rs.getString("city"));
					provinceChoiceBox.setText(rs.getString("province"));
					postalCodeField1.setText(rs.getString("postalCode"));
					phoneNumberField.setText(rs.getString("organizationPhoneNumber"));
					missionVisionTextArea.setText(rs.getString("mission"));

				}

				//done
				con.close();

			}catch (Exception e) {System.out.print(e);}

		}
		
		//Submit the edit org request
		public void submit(ActionEvent event) throws IOException{
			//account id
			int id= CurrentUser.getCurrentUser();
			//Hardcoded org ID since 2 orgs have same orgID... might have to change this. but for demo should be okay?
			String orgID= "0";
			try {
				Connection con = ConnectionProvider.getCon();
				Statement stmt = con.createStatement();
				String sql= "update organizations set organizationName ='" +organizationNameField.getText() + "' ,organizationURL= '" + websiteURLField.getText() + "' ,streetAddress = '" + streetAddressField.getText()+ "', \n"+
						"unitNumber= '" +unitNumberField.getText() + "', city= '" +cityField.getText() + "' , province='" +provinceChoiceBox.getText()+ "',postalCode='" + postalCodeField1.getText()+ "'\n"+
						",organizationPhoneNumber='" + phoneNumberField.getText() + "', mission= '" +missionVisionTextArea.getText() + "' where organizationID= '"+orgID+"'";
				int rs = stmt.executeUpdate(sql);
				System.out.println("updated: "+ rs);


				Alert alert = new Alert(Alert.AlertType.INFORMATION);
				alert.setTitle("Edit Organization");
				alert.setHeaderText(null);
				alert.setContentText("Modification Successful!");

				alert.showAndWait();

				//done
				con.close();

			}catch (Exception e) {System.out.print(e);}


			MainController m = new MainController();
			m.changeScene("HomePageOrganization.fxml");
		}
		
		public void back(ActionEvent event) throws IOException{
			MainController m = new MainController();
			m.changeScene("HomePageOrganization.fxml");
		}
}
