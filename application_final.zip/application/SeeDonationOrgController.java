package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;

public class SeeDonationOrgController implements Initializable {

	   @FXML
	    private Button logoutButton;
	   @FXML
	    private TableView<HelperClassTable> donationTable;
	   @FXML
	    private TableColumn<HelperClassTable, String> namecol;
	   @FXML
	    private TableColumn<HelperClassTable, String> itemcol;
	   @FXML
	    private TableColumn<HelperClassTable, String> qualitycol;
		@FXML
		private TableColumn<HelperClassTable, String> donationStatusCol;
	   @FXML
		public ComboBox<String> selectComboBox;
	   @FXML
	   private ListView lv_combo;
	   
	   //public ObservableList<String> column1List;
	   
	   //Adding to table to give an example of how it is done
	   public ObservableList<HelperClassTable> list;
	   private ObservableList<String> comboList;
		//	   new HelperClassTable("Angel","Water Bottle","Bad"),
		//	   new HelperClassTable("Shane","Bag","Good")
		//	   );

	   //When this web page opens it should display all donor in table and donor name is comboBox
	   @Override
		public void initialize(URL arg0, ResourceBundle arg1) {
		   namecol.setCellValueFactory(new PropertyValueFactory<HelperClassTable, String>("donationID"));
		   itemcol.setCellValueFactory(new PropertyValueFactory<HelperClassTable, String>("item"));
		   qualitycol.setCellValueFactory(new PropertyValueFactory<HelperClassTable, String>("quality"));
		   donationStatusCol.setCellValueFactory(new PropertyValueFactory<HelperClassTable, String>("donationStatus"));

		   //call query to get list of donors.

		   list =  FXCollections.observableArrayList();
		   comboList=FXCollections.observableArrayList();
		   //call query to get all volunteers
		   try {
			   Connection con = ConnectionProvider.getCon();
			   Statement stmt = con.createStatement();
			   String sql= "select  donations.donationID as donationID ,donors.donorID as donorID, donations.itemsDonated as items ,volunteers.volunteerID as volunteerID, donations.donationStatus as donationStatus from donations inner join donors on donations.donorID =donors.donorID \n" +
					   "inner join organizations on donations.organizationID = organizations.organizationID inner join volunteers on donations.volunteerID =volunteers.volunteerID where organizations.organizationID = '1'";
			   ResultSet rs = stmt.executeQuery(sql);


			   while(rs.next())
			   {
				   System.out.println("got donors..");
				   String s= String.format("%s",rs.getInt("donationID"));
				   HelperClassTable n= new HelperClassTable(rs.getString("donationID"), rs.getString("items"), rs.getString("volunteerID"),rs.getString("donationStatus"));
				   list.add(n);
				   comboList.add(s);
			   }

			   //done
			   con.close();

		   }catch (Exception e) {System.out.print(e);}
		   donationTable.setItems(list);
		   //fill combo box
		   selectComboBox.setItems(comboList);
		   
		   //Add the names to the combox box so user can see more details about that donation
		}

	 public void comboBoxAction(ActionEvent event)	{
		 String id = selectComboBox.getValue().toString();
		 ObservableList<String> lv_strings= FXCollections.observableArrayList();
		 lv_combo.getItems().clear();

		 String s="";

		 try {
			 Connection con = ConnectionProvider.getCon();
			 Statement stmt = con.createStatement();
			 String sql= "select  donations.donationID as donationID ,donors.donorID as donorID, donations.itemsDonated as items ,volunteers.volunteerID as volunteerID , organizations.organizationName as organizationName , donations.timeRequested as TimeandDateRequested, donations.donationStatus as Status from donations inner join donors on donations.donorID =donors.donorID \n" +
					 "inner join organizations on donations.organizationID = organizations.organizationID inner join volunteers on donations.volunteerID =volunteers.volunteerID where donations.donationID= '" + id +"'";
			 ResultSet rs = stmt.executeQuery(sql);


			 if(rs.next())
			 {
				 ResultSetMetaData rsmd = rs.getMetaData();
				 int colcount= rsmd.getColumnCount();
				 //System.out.println(colcount);
				 for(int i=1; i<=colcount;i++)
				 {
					 s = s.concat(rsmd.getColumnName(i).toString()+ " : "+rs.getString(i).toString()+ "\n");
					 String item= rsmd.getColumnName(i).toString()+ " : "+rs.getString(i).toString();
					 lv_combo.getItems().add(item);

				 }


			 }
			 //System.out.println(s);
			 Alert alert = new Alert(Alert.AlertType.INFORMATION);
			 alert.setTitle("Donation Information");
			 alert.setHeaderText(null);
			 alert.setContentText(s);

			 alert.showAndWait();
			 //done
			 con.close();

		 }catch (Exception e) {System.out.print(e);}

	 }
	 public void back(ActionEvent event) throws IOException{
	    	MainController m = new MainController();
			m.changeScene("HomePageOrganization.fxml");
	    }
	   
	 public void logOutFromAccount(ActionEvent event) throws IOException{
	    	MainController m = new MainController();
			m.changeScene("loginUpdated.fxml");
	    }
	 public void receiveDonation(ActionEvent event) throws IOException{
		String id = donationTable.getSelectionModel().getSelectedItem().getDonationID();
		//
		//send query change status to onRoute and volunteer ID to their id
		try {
			Connection con = ConnectionProvider.getCon();
			Statement stmt = con.createStatement();
			String sql= "update donations set donationStatus = 'received' where donationID= '"+ id +"'";
			int rs = stmt.executeUpdate(sql);
			System.out.println("updated: "+ rs);


			Alert alert = new Alert(Alert.AlertType.INFORMATION);
			alert.setTitle("Donation: "+id +" Received");
			alert.setHeaderText(null);
			alert.setContentText("Donation in the System!");

			alert.showAndWait();

			//done
			con.close();

		}catch (Exception e) {System.out.print(e);}
		//show alert safe drive


	}

	
}
