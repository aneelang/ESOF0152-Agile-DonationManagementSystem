package application;

import javafx.beans.property.SimpleStringProperty;

public class HelperClassTable2 {

	private SimpleStringProperty donationID;
	private SimpleStringProperty name;
	private SimpleStringProperty address;
	private SimpleStringProperty postalCode;
	private SimpleStringProperty phoneNumber;
	private SimpleStringProperty pickUpDate;
	private SimpleStringProperty donationStatus;
	
	public HelperClassTable2(String donationID,String name, String address, String postalCode, String phoneNumber, String pickUpDate, String donationStatus) {
		//super();
		this.donationID= new SimpleStringProperty(donationID);
		this.name = new SimpleStringProperty(name);
		this.address = new SimpleStringProperty(address);
		this.postalCode = new SimpleStringProperty(postalCode);
		this.phoneNumber = new SimpleStringProperty(phoneNumber);
		this.pickUpDate = new SimpleStringProperty(pickUpDate);
		this.donationStatus = new SimpleStringProperty(donationStatus);
	}
	public String getDonationID() {
		return donationID.get();
	}
	public String getName() {
		return name.get();
	}
	public String getAddress() {
		return address.get();
	}
	public String getPostalCode() {
		return postalCode.get();
	}
	public String getPhoneNumber() {
		return phoneNumber.get();
	}
	public String getPickUpDate() {
		return pickUpDate.get();
	}
	public String getDonationStatus() {
		return donationStatus.get();
	}
}