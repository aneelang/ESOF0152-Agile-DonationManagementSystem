package application;

import javafx.beans.property.SimpleStringProperty;

public class HelperClassTable {

	private SimpleStringProperty donationID;
	private SimpleStringProperty item;
	private SimpleStringProperty quality;
	private SimpleStringProperty donationStatus;

	
	public HelperClassTable(String donationID, String item, String quality,String donationStatus) {
		//super();
		this.donationID = new SimpleStringProperty(donationID);
		this.item = new SimpleStringProperty(item);
		this.quality = new SimpleStringProperty(quality);
		this.donationStatus = new SimpleStringProperty(donationStatus);
	}
	public String getDonationID(){
		return donationID.get();
	}

	public String getItem() {
		return item.get();
	}
	public String getQuality() {
		return quality.get();
	}
	public String getDonationStatus() {
		return donationStatus.get();
	}
}
