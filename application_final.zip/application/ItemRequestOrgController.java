package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

public class ItemRequestOrgController implements Initializable {

	@FXML
	private TextArea t_list;
	@FXML
	private Button logoutButton;
	@FXML
	private Button backButton;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		//account id
		int id= CurrentUser.getCurrentUser();

		//Hardcoded org ID since 2 orgs have same orgID... might have to change this. but for demo should be okay?
		String orgID= "1";
		//first fill
		try {
			Connection con = ConnectionProvider.getCon();
			Statement stmt = con.createStatement();
			String sql= "select * from organizations where organizationID='"+ orgID+"'";
			ResultSet rs = stmt.executeQuery(sql);

			if(rs.next())
			{
				System.out.println("got org info..");
				t_list.setText(rs.getString("itemsRequestedFromDonors"));

			}

			//done
			con.close();

		}catch (Exception e) {System.out.print(e);}


	}

	public void makeChange(ActionEvent event) throws IOException{
		//account id
		int id= CurrentUser.getCurrentUser();
		//Hardcoded org ID since 2 orgs have same orgID... might have to change this. but for demo should be okay?
		String orgID= "1";
		try {
			Connection con = ConnectionProvider.getCon();
			Statement stmt = con.createStatement();
			String sql= "update organizations set itemsRequestedFromDonors ='" +t_list.getText().toString() + "' where organizationID= '"+orgID+"'";
			int rs = stmt.executeUpdate(sql);


			Alert alert = new Alert(Alert.AlertType.INFORMATION);
			alert.setTitle("Edit Item Request");
			alert.setHeaderText(null);
			alert.setContentText("Modification Successful!");

			alert.showAndWait();

			//done
			con.close();

		}catch (Exception e) {System.out.print(e);}


		MainController m = new MainController();
		m.changeScene("HomePageOrganization.fxml");
	}
	
	public void logOutFromAccount(ActionEvent event) throws IOException{
		MainController m = new MainController();
		m.changeScene("loginUpdated.fxml");
	}
	
	public void back(ActionEvent event) throws IOException{
		MainController m = new MainController();
		m.changeScene("HomePageOrganization.fxml");
	}
}
